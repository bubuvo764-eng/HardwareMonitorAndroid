package com.example.hardwaremonitor;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Typeface;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private TextView cpuValue, cpuDetail, gpuValue, gpuDetail, ramValue, ramDetail,
            tempValue, tempDetail, chipValue, chipDetail, benchValue, status;
    private LineChart chart;
    private double lastTotal = -1, lastIdle = -1;
    private String gpuRenderer = "Đang truy vấn GPU…";
    private int tick = 0;
    private boolean running = true;

    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            if (!running) return;
            updateStats();
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildInterface();
        queryGpu();
        handler.post(refresh);
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout card(String title) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(roundBg(0xFF182333, 18));
        TextView heading = text(title, 13, 0xFF9FB0C5, true);
        box.addView(heading);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(12);
        return box;
    }

    private android.graphics.drawable.GradientDrawable roundBg(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF0B1220);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(28), dp(18), dp(24));
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView title = text("HARDWARE MONITOR", 19, 0xFFF4F7FB, true);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        status = text("● LIVE", 12, 0xFF45D49A, true);
        top.addView(status);
        root.addView(top);
        TextView sub = text("Giám sát hiệu năng thiết bị", 13, 0xFF8292A8, false);
        LinearLayout.LayoutParams subp = new LinearLayout.LayoutParams(-1,-2); subp.topMargin=dp(5); subp.bottomMargin=dp(20);
        root.addView(sub, subp);

        LinearLayout cpu = card("CPU • TẢI HỆ THỐNG");
        cpuValue = text("--%", 34, 0xFF69B7FF, true);
        cpuDetail = text("Đang thu thập dữ liệu…", 12, 0xFF9FB0C5, false);
        cpu.addView(cpuValue); cpu.addView(cpuDetail);
        addCard(root, cpu);

        LinearLayout gpu = card("GPU • ĐỒ HỌA");
        gpuValue = text("Không khả dụng", 22, 0xFFC1A4FF, true);
        gpuDetail = text("Android không cung cấp mức tải GPU chung cho mọi thiết bị.", 12, 0xFF9FB0C5, false);
        gpu.addView(gpuValue); gpu.addView(gpuDetail);
        addCard(root, gpu);

        LinearLayout ram = card("RAM • BỘ NHỚ");
        ramValue = text("--", 28, 0xFF55D6B0, true);
        ramDetail = text("", 12, 0xFF9FB0C5, false);
        ram.addView(ramValue); ram.addView(ramDetail);
        addCard(root, ram);

        LinearLayout temp = card("NHIỆT ĐỘ");
        tempValue = text("-- °C", 28, 0xFFFFC46B, true);
        tempDetail = text("Nhiệt độ pin; không phải nhiệt độ CPU/GPU.", 12, 0xFF9FB0C5, false);
        temp.addView(tempValue); temp.addView(tempDetail);
        addCard(root, temp);

        LinearLayout chip = card("THÔNG TIN CHIP & THIẾT BỊ");
        chipValue = text(Build.HARDWARE, 20, 0xFFF4F7FB, true);
        chipDetail = text("", 12, 0xFF9FB0C5, false);
        chip.addView(chipValue); chip.addView(chipDetail);
        addCard(root, chip);

        LinearLayout graph = card("BIỂU ĐỒ CPU • THỜI GIAN THỰC");
        chart = new LineChart(this);
        graph.addView(chart, new LinearLayout.LayoutParams(-1, dp(150)));
        addCard(root, graph);

        LinearLayout bench = card("BENCHMARK CPU");
        benchValue = text("Chưa chạy", 24, 0xFFFFFFFF, true);
        TextView note = text("Bài kiểm tra tính toán ngắn trên CPU. Điểm số chỉ để so sánh tương đối trên cùng thiết bị.", 12, 0xFF9FB0C5, false);
        Button run = new Button(this);
        run.setText("CHẠY BENCHMARK");
        run.setTextColor(0xFFFFFFFF);
        run.setBackground(roundBg(0xFF2367C9, 12));
        run.setAllCaps(false);
        run.setOnClickListener(v -> runBenchmark());
        bench.addView(benchValue);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,-2); np.topMargin=dp(6);
        bench.addView(note,np);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(48)); bp.topMargin=dp(14);
        bench.addView(run,bp);
        addCard(root, bench);

        TextView disclaimer = text("LƯU Ý: Android giới hạn quyền truy cập cảm biến và thống kê GPU. Các mục không được hệ thống công khai sẽ hiển thị là không khả dụng thay vì tạo số liệu giả.", 11, 0xFF78889D, false);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1,-2); dp.topMargin=dp(4);
        root.addView(disclaimer, dp);
        setContentView(scroll);
        updateChipInfo();
    }

    private void addCard(LinearLayout root, LinearLayout c) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.bottomMargin = dp(12); root.addView(c,p);
    }

    private void updateChipInfo() {
        int cores = Runtime.getRuntime().availableProcessors();
        String model = Build.MODEL == null ? "Không rõ" : Build.MODEL;
        String maker = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER;
        chipValue.setText(Build.HARDWARE == null ? "Không rõ SoC" : Build.HARDWARE);
        chipDetail.setText("Thiết bị: " + maker + " " + model + "\nCPU logic: " + cores +
                " lõi\nABI: " + Build.SUPPORTED_ABIS[0] + "\nAndroid: " + Build.VERSION.RELEASE +
                " (API " + Build.VERSION.SDK_INT + ")\nGPU renderer: " + gpuRenderer);
    }

    private void queryGpu() {
        GLSurfaceView gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(2);
        gl.setRenderer(new GLSurfaceView.Renderer() {
            public void onSurfaceCreated(GL10 gl10, EGLConfig config) {
                String r = GLES20.glGetString(GLES20.GL_RENDERER);
                runOnUiThread(() -> { gpuRenderer = r == null ? "Không đọc được" : r; gpuValue.setText(gpuRenderer); gpuDetail.setText("Tên bộ kết xuất đồ họa • Mức tải GPU không được Android cung cấp phổ quát."); updateChipInfo(); });
            }
            public void onSurfaceChanged(GL10 gl10, int w, int h) {}
            public void onDrawFrame(GL10 gl10) {}
        });
        gl.setLayoutParams(new LinearLayout.LayoutParams(1,1));
        addContentView(gl, new android.view.ViewGroup.LayoutParams(1,1));
    }

    private void updateStats() {
        double usage = readCpuUsage();
        if (usage >= 0) {
            cpuValue.setText(String.format(Locale.US, "%.0f%%", usage));
            cpuDetail.setText("Tần suất CPU hiện đọc được: " + readCpuFrequency());
            chart.add((float)usage);
        } else {
            cpuValue.setText("Không khả dụng");
            cpuDetail.setText("Thiết bị chặn quyền đọc /proc/stat.");
        }

        ActivityManager am = (ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long total = mi.totalMem, avail = mi.availMem, used = total-avail;
        ramValue.setText(String.format(Locale.getDefault(), "%.0f%%", total == 0 ? 0 : used*100.0/total));
        ramDetail.setText(String.format(Locale.getDefault(), "Đã dùng %.2f GB / %.2f GB • Còn trống %.2f GB",
                used/1073741824.0, total/1073741824.0, avail/1073741824.0));

        try {
            int temp = ((BatteryManager)getSystemService(BATTERY_SERVICE)).getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
            android.content.Intent battery = registerReceiver(null, new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED));
            int tenths = battery == null ? -1 : battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            if (tenths >= 0) tempValue.setText(String.format(Locale.getDefault(), "%.1f °C", tenths/10.0));
            else tempValue.setText("Không khả dụng");
        } catch (Exception e) { tempValue.setText("Không khả dụng"); }
        tick++;
    }

    private double readCpuUsage() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("/proc/stat"));
            String line = br.readLine(); br.close();
            if (line == null || !line.startsWith("cpu ")) return -1;
            String[] p = line.trim().split("\\s+");
            double total=0; for(int i=1;i<p.length;i++) total += Long.parseLong(p[i]);
            double idle = Long.parseLong(p[4]) + (p.length>5 ? Long.parseLong(p[5]) : 0);
            if(lastTotal < 0) { lastTotal=total; lastIdle=idle; return 0; }
            double dt=total-lastTotal, di=idle-lastIdle; lastTotal=total; lastIdle=idle;
            return dt <= 0 ? 0 : Math.max(0,Math.min(100,(dt-di)*100.0/dt));
        } catch(Exception e) { return -1; }
    }

    private String readCpuFrequency() {
        File dir = new File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq");
        try (BufferedReader br = new BufferedReader(new FileReader(dir))) {
            return String.format(Locale.US, "%.0f MHz", Long.parseLong(br.readLine().trim())/1000.0);
        } catch(Exception e) { return "không được hệ thống cho phép"; }
    }

    private void runBenchmark() {
        benchValue.setText("Đang kiểm tra…");
        executor.execute(() -> {
            long start=System.nanoTime();
            double x=0;
            for(int i=1;i<8_000_000;i++) x += Math.sqrt(i)*Math.sin(i);
            long ms=(System.nanoTime()-start)/1_000_000;
            long score=Math.max(1, 8_000_000L*1000/Math.max(1,ms));
            final String result=String.format(Locale.US,"%,d điểm  •  %d ms",score,ms);
            runOnUiThread(() -> benchValue.setText(result));
        });
    }

    @Override protected void onDestroy() {
        running=false; handler.removeCallbacks(refresh); executor.shutdownNow(); super.onDestroy();
    }

    private static class LineChart extends View {
        private final Paint line=new Paint(3), grid=new Paint(3);
        private final ArrayList<Float> values=new ArrayList<>();
        public LineChart(Context c) {
            super(c); line.setColor(0xFF55B5FF); line.setStrokeWidth(4); line.setStyle(Paint.Style.STROKE);
            grid.setColor(0xFF344357); grid.setStrokeWidth(1);
        }
        void add(float v) { values.add(v); if(values.size()>45) values.remove(0); postInvalidate(); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float w=getWidth(), h=getHeight();
            for(int i=1;i<4;i++) c.drawLine(0,h*i/4,w,h*i/4,grid);
            if(values.size()<2) return;
            Path p=new Path();
            for(int i=0;i<values.size();i++) {
                float x=w*i/44f, y=h-(values.get(i)/100f)*(h-12)-6;
                if(i==0)p.moveTo(x,y); else p.lineTo(x,y);
            }
            c.drawPath(p,line);
        }
    }
}
